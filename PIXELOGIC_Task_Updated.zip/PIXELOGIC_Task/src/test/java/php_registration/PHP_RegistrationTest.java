package php_registration;

import base.BaseTests;
import com.github.javafaker.Faker;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;
import phptravels.MyAccountPage;
import phptravels.SignUpPage;
import readers.JsonReader;

import java.io.IOException;

@Test(priority=1,alwaysRun=true)
public class PHP_RegistrationTest extends BaseTests{
    SignUpPage signUpPage;
    MyAccountPage myAccountPage;
    //Generate Fake data for Email and password
    Faker fakeData = new Faker();
    public String email = fakeData.internet().emailAddress();
    public String password = fakeData.number().digits(8).toString();




    public void registerSuccessfully() throws IOException, ParseException, InterruptedException {
        JsonReader jsonReader = new JsonReader();
        jsonReader.jsonReaderMethod();

        signUpPage= new SignUpPage(driver);
        myAccountPage=new MyAccountPage(driver);
        //Call setter methods
        signUpPage.setFirstNameField(jsonReader.firstname);
        signUpPage.setLastNameField(jsonReader.lastname);
        signUpPage.setMobileNumField(jsonReader.phone);
        signUpPage.setEmailField(email);
        signUpPage.setPasswordField(password);
        signUpPage.setConfirmPasswordField(password);

        //scroll Down by javascript
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,500)");

        //Call click Sign Up button method
        signUpPage.clickSignUpButton();
        //Call assertion method
        myAccountPage.successfulLoginAssertion();


    }

}





