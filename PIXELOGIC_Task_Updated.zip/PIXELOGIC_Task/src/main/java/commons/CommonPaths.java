package commons;

public class CommonPaths {
    public static final String BINARIES =System.getProperty("user.dir")+"/src/main/resources/binaries/";
    public static final String JSONFILE =System.getProperty("user.dir")+"/src/test/java/testdata/uservaliddata.json";
    public static final String SCREENSHOTS=System.getProperty("user.dir")+"/src/main/java/utilities/screenshots";

}