package readers;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import static commons.CommonPaths.JSONFILE;



public class JsonReader {
    public String firstname, lastname, phone;

    public void jsonReaderMethod() throws IOException, ParseException {
        File srcfile = new File(JSONFILE);
        JSONParser parser = new JSONParser();
        JSONArray jarray = (JSONArray) parser.parse(new FileReader(srcfile));

        for (Object jsonObj : jarray) {
            JSONObject user = (JSONObject) jsonObj;
            firstname = (String) user.get("firstname");
           //System.out.println(firstname);
            lastname = (String) user.get("lastname");
            phone = (String) user.get("phone");


        }
    }
}

