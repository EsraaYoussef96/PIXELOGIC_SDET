package utilities;

import com.google.common.io.Files;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;

import java.io.File;
import java.io.IOException;

import static commons.CommonPaths.SCREENSHOTS;


public class ScreenshotTaker {

    private WebDriver driver;
    public ScreenshotTaker (WebDriver driver){
        this.driver=driver;
    }

    // Take Screenshot in case of test failure only ..
    public void recordFailure(ITestResult result) {
        if (ITestResult.FAILURE == result.getStatus()) {
            var camera = (TakesScreenshot) driver;
            File screenshot = camera.getScreenshotAs(OutputType.FILE);
            System.out.println("Screenshot taken ");

            try {
                Files.move(screenshot, new File(SCREENSHOTS+result.getName()+".png"));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}
