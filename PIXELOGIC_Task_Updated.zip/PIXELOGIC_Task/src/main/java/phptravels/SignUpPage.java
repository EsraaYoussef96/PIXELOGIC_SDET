package phptravels;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class SignUpPage {

    private WebDriver driver;
    public SignUpPage(WebDriver driver){
        this.driver=driver;
    }
// Define page locators
    private By firstNameField = By.name("firstname");
    private By lastNameField = By.name("lastname");
    private By mobileNumField = By.name("phone");
    private By signUpButton   = By.xpath("//div/button[@class='signupbtn btn_full btn btn-success btn-block btn-lg']");
    private By emailField = By.name("email");
    private By passwordField = By.name("password");
    private By confirmPasswordField = By.name("confirmpassword");

// setter methods
public void setFirstNameField(String firstname){
        driver.findElement(firstNameField).sendKeys(firstname);
}

public void setLastNameField(String lastname){
        driver.findElement(lastNameField).sendKeys(lastname);
    }

    public void setMobileNumField(String mobile){
        driver.findElement(mobileNumField).sendKeys(mobile);
    }
    public void setEmailField(String email) {
        driver.findElement(emailField).sendKeys(email);
    }

    public void setPasswordField(String password) {
        driver.findElement(passwordField).sendKeys(password);
    }

    public void setConfirmPasswordField(String password) {
        driver.findElement(confirmPasswordField).sendKeys(password);
    }

    public void clickSignUpButton(){
        driver.findElement(signUpButton).click();
    }


}
