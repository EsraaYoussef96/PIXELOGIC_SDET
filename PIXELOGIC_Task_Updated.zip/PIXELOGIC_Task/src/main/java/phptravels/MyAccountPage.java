package phptravels;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
public class MyAccountPage {

    private WebDriver driver;

    public MyAccountPage (WebDriver driver){
        this.driver=driver;
    }

    public void successfulLoginAssertion() {
        //Successful registration assertion
        WebDriverWait wait = new WebDriverWait(driver,60);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[@href='#bookings']")));

        Assert.assertEquals(driver.getTitle(),"My Account");

    }
}
